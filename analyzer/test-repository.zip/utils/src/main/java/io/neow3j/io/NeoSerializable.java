package io.neow3j.io;

public abstract class NeoSerializable implements NeoSerializableInterface {

}
