package io.neow3j.contract;

import io.neow3j.io.BinaryReader;
import io.neow3j.io.BinaryWriter;
import io.neow3j.io.NeoSerializable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

public class ContractInvocationScript extends NeoSerializable {

    private static final Logger LOG = LoggerFactory.getLogger(ContractInvocationScript.class);

    @Override
    public void deserialize(BinaryReader reader) throws IOException {
        // TODO: 2019-07-03 Guil: to be implemented
    }

    @Override
    public void serialize(BinaryWriter writer) throws IOException {
        // TODO: 2019-07-03 Guil: to be implemented
    }
}
